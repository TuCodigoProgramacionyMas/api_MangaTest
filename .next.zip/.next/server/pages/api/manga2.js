"use strict";
(() => {
var exports = {};
exports.id = 230;
exports.ids = [230];
exports.modules = {

/***/ 198:
/***/ ((module) => {

module.exports = require("chrome-aws-lambda");

/***/ }),

/***/ 18:
/***/ ((module) => {

module.exports = require("puppeteer");

/***/ }),

/***/ 155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getCombustibles)
/* harmony export */ });
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(198);
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
// npm i puppeteer
// npm i chrome-aws-lambda

async function getBrowserInstance() {
    const executablePath = await (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().executablePath);
    const puppeteer = __webpack_require__(18);
    return puppeteer.launch({
        args: [
            ...(chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().args),
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--single-process"
        ],
        executablePath: executablePath || undefined,
        headless: true,
        ignoreHTTPSErrors: true
    });
}
async function getCombustibles(req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    res.setHeader("Access-Control-Allow-Headers", "X-Requested-With,content-type");
    res.setHeader("Access-Control-Allow-Credentials", true);
    let browser = null;
    let result = null;
    try {
        browser = await getBrowserInstance();
        let page = await browser.newPage();
        await page.setRequestInterception(true);
        page.on("request", (request)=>{
            if ([
                "image",
                "stylesheet"
            ].includes(request.resourceType())) {
                request.abort();
            } else {
                request.continue();
            }
        });
        await page.setJavaScriptEnabled(false);
        await page.goto("https://www.leercapitulo.com/leer/or1iu9/one-punch-man/182/", {
            waitUntil: "domcontentloaded"
        });
        await page.waitForSelector("#arraydata");
        result = await page.evaluate(()=>{
            const div = document.querySelector("div.select_page_2");
            const tds = Array.from(div.querySelectorAll("option"));
            return tds.map((td)=>td.value);
        });
        await browser.close();
        res.json(result);
    } catch (error) {
        res.status(400).json(error);
        console.log(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(155));
module.exports = __webpack_exports__;

})();