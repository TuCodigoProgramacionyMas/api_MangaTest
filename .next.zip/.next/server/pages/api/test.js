"use strict";
(() => {
var exports = {};
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 198:
/***/ ((module) => {

module.exports = require("chrome-aws-lambda");

/***/ }),

/***/ 18:
/***/ ((module) => {

module.exports = require("puppeteer");

/***/ }),

/***/ 183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getCombustibles)
/* harmony export */ });
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(198);
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
// npm i puppeteer
// npm i chrome-aws-lambda

async function getBrowserInstance() {
    const executablePath = await (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().executablePath);
    const puppeteer = __webpack_require__(18);
    if (!executablePath) {
        // running locally
        return puppeteer.launch({
            args: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().args),
            headless: true,
            ignoreHTTPSErrors: true
        });
    }
    return chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().puppeteer.launch({
        args: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().args),
        executablePath,
        headless: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().headless),
        ignoreHTTPSErrors: true
    });
}
async function getCombustibles(req, res) {
    /*  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );
  res.setHeader("Access-Control-Allow-Credentials", true);
 */ let browser = null;
    let result = null;
    var comb = [];
    var fecha = [];
    try {
        browser = await getBrowserInstance();
        let page1 = await browser.newPage();
        await page1.goto("https://www.conectate.com.do/articulo/precio-combustible-republica-dominicana/");
        page1 = await page1.waitForSelector("th");
        console.log(page1);
    /*     for (let i = 0; i < 35; i = i + 5) {
      comb.push({
        Combustible: result[i],
        PrecioAnterior: result[i + 1],
        PrecioActual: result[i + 2],
        Diferencia: result[i + 3],
        EstadoAlsa: result[i + 4],
      });
    }

    let result2 = null;

    result2 = await page.evaluate(() => {
      const tds = Array.from(document.querySelectorAll("table tr th"));
      return tds.map((td) => td.innerText);
    });

    fecha.push({
      SemanaAnterior: result2[1],
      SemanaActual: result2[2],
    }); */ } catch (error) {
        res.status(400).json(error);
        console.log(error);
    }
    res.json({
        page
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(183));
module.exports = __webpack_exports__;

})();