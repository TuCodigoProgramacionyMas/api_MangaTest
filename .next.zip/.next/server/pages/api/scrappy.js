"use strict";
(() => {
var exports = {};
exports.id = 983;
exports.ids = [983];
exports.modules = {

/***/ 198:
/***/ ((module) => {

module.exports = require("chrome-aws-lambda");

/***/ }),

/***/ 462:
/***/ ((module) => {

module.exports = import("puppeteer");;

/***/ }),

/***/ 614:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getCombustibles)
/* harmony export */ });
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(198);
/* harmony import */ var chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var puppeteer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(462);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([puppeteer__WEBPACK_IMPORTED_MODULE_1__]);
puppeteer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function getBrowserInstance() {
    const executablePath = await (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().executablePath);
    if (!executablePath) {
        return puppeteer__WEBPACK_IMPORTED_MODULE_1__["default"].launch({
            args: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().args),
            headless: true,
            ignoreHTTPSErrors: true
        });
    }
    return chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().puppeteer.launch({
        args: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().args),
        executablePath,
        headless: (chrome_aws_lambda__WEBPACK_IMPORTED_MODULE_0___default().headless),
        ignoreHTTPSErrors: true
    });
}
async function getCombustibles(req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    res.setHeader("Access-Control-Allow-Headers", "X-Requested-With,content-type");
    res.setHeader("Access-Control-Allow-Credentials", true);
    // Check if url query parameter is available
    const targetUrl = req.query.url;
    if (!targetUrl) {
        return res.status(400).json({
            error: "URL not provided"
        });
    }
    let browser = null;
    try {
        browser = await getBrowserInstance();
        const page = await browser.newPage();
        await page.setRequestInterception(true);
        page.on("request", (request)=>[
                "image",
                "stylesheet"
            ].includes(request.resourceType()) ? request.abort() : request.continue());
        await page.goto(targetUrl);
        const htmlContent = await page.content();
        await browser.close();
        res.json({
            htmlContent
        });
    } catch (error) {
        res.status(400).json({
            error: error.toString()
        });
        console.error(error);
    } finally{
        if (browser) {
            await browser.close();
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(614));
module.exports = __webpack_exports__;

})();